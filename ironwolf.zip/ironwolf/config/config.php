<?php
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', 'root'); // Change if using no password
define('DB_NAME', 'ironwolf');

define('APPROOT', dirname(dirname(__FILE__))); // C:\xampp\htdocs\ironwolf\app
define('URLROOT', 'http://localhost/ironwolf/public');
define('SITENAME', 'IronWolf');
