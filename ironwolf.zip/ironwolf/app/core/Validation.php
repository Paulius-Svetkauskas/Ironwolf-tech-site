<?php
class Validation {
    public static function sanitize($data){
        return htmlspecialchars(strip_tags(trim($data)));
    }

    public static function isEmail($email){
        return filter_var($email, FILTER_VALIDATE_EMAIL);
    }

    public static function isPasswordStrong($password){
        return preg_match('/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W]).{8,}$/', $password);
    }
}
