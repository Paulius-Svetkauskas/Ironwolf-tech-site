<?php
class UserController extends Controller {
    private $userModel;

    public function __construct() {
        $this->userModel = $this->model('User');
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = trim($_POST['username']);
            $email = trim($_POST['email']);
            $password = $_POST['password'];
            $confirm = $_POST['confirm_password'];

            if ($password !== $confirm) {
                die('Passwords do not match.');
            }

            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $this->userModel->register($username, $email, $hashedPassword);

            header('Location: ' . URLROOT . '/user/login');
        } else {
            $this->view('users/register');
        }
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $username = trim($_POST['username']);
            $password = $_POST['password'];
            $user = $this->userModel->findUserByUsername($username);

            if ($user && password_verify($password, $user->password)) {
                $_SESSION['user_id'] = $user->id;
                $_SESSION['username'] = $user->username;
                header('Location: ' . URLROOT . '/');
            } else {
                die('Invalid credentials');
            }
        } else {
            $this->view('users/login');
        }
    }

    public function logout() {
        session_unset();
        session_destroy();
        header('Location: ' . URLROOT . '/user/login');
    }

    public function account() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: ' . URLROOT . '/user/login');
            exit;
        }

        $user = $this->userModel->findUserById($_SESSION['user_id']);
        $this->view('users/account', ['user' => $user]);
    }

    public function delete() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
            $this->userModel->deleteUser($_SESSION['user_id']);
            session_unset();
            session_destroy();
            header('Location: ' . URLROOT . '/user/register');
        }
    }
}