<?php
class ProductController extends Controller {
    private $productModel;

    public function __construct() {
        $this->productModel = $this->model('Product');
    }

    public function index() {
        $products = $this->productModel->getAllProducts();
        
    if (empty($products)) {
        $products = [
            (object)[ 'name' => 'Sample Laptop', 'description' => 'A great device.', 'price' => 899.99 ],
            (object)[ 'name' => 'Resin Printer', 'description' => 'High-detail 3D printing.', 'price' => 299.99 ],
            (object)[ 'name' => 'Repair Kit', 'description' => 'Tools for electronics repair.', 'price' => 59.99 ]
        ];
    }
    $this->view('products/index', ['products' => $products]);
     // changed 'list' to 'index'
    }

    public function show($id) {
        $product = $this->productModel->getProductById($id);
        $this->view('products/detail', ['product' => $product]);
    }

    public function addToCart($id) {
        $product = $this->productModel->getProductById($id);
        if ($product) {
            if (!isset($_SESSION['cart'][$id])) {
                $_SESSION['cart'][$id] = [
                    'name' => $product->name,
                    'price' => $product->price,
                    'qty' => 1
                ];
            } else {
                $_SESSION['cart'][$id]['qty'] += 1;
            }
        }
        header('Location: ' . URLROOT . '/product/cart');
    }

    public function removeFromCart($id) {
        if (isset($_SESSION['cart'][$id])) {
            unset($_SESSION['cart'][$id]);
        }
        header('Location: ' . URLROOT . '/product/cart');
    }

    public function cart() {
        $this->view('products/cart', ['cart' => $_SESSION['cart'] ?? []]);
    }

    public function checkout() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // simulate order processing
            unset($_SESSION['cart']);
            echo "<script>alert('Order placed successfully!'); window.location.href='" . URLROOT . "/product';</script>";
        } else {
            $this->view('products/checkout');
        }
    }
}
