<?php require APPROOT . '/app/views/templates/header.php'; ?>

<div class="container mt-5">
    <h1>Welcome to IronWolf</h1>
    <p class="lead">
        IronWolf is your trusted local provider of high-quality tech solutions. We specialize in fast, affordable, and reliable services across a range of devices and technologies.
    </p>

    <hr>

    <h2>What We Do</h2>
    <ul>
        <li><strong>PC Repairs:</strong> Hardware diagnostics, part replacement, software cleanup, and performance optimization.</li>
        <li><strong>Laptop & Phone Repairs:</strong> Cracked screens, battery replacements, OS reinstallations, and general troubleshooting.</li>
        <li><strong>3D Printing Services:</strong> Precision prints using resin and PLA for custom projects, prototypes, parts, and miniatures.</li>
        <li><strong>Online Store:</strong> Browse tech accessories, upgrade kits, repair tools, and more.</li>
    </ul>

    <h2>Why Choose IronWolf?</h2>
    <ul>
        <li>Local and friendly support</li>
        <li>Affordable pricing</li>
        <li>Quick turnaround times</li>
        <li>Skilled, qualified technicians</li>
        <li>Secure handling of your devices and data</li>
    </ul>

    <p>
        Whether you're fixing a device or looking for custom 3D prints, IronWolf is here to help. 
        <a href="<?= URLROOT ?>/product" class="btn btn-primary mt-2">Browse Our Products</a>
    </p>
</div>

<?php require APPROOT . '/app/views/templates/footer.php'; ?>
