<?php require APPROOT . '/app/views/templates/header.php'; ?>

<h2>Your Shopping Cart</h2>

<?php if (empty($data['cart'])): ?>
  <p>Your cart is empty.</p>
<?php else: ?>
  <table class="table table-dark table-striped">
    <thead>
      <tr>
        <th>Product</th>
        <th>Qty</th>
        <th>Price</th>
        <th>Total</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php $grandTotal = 0; ?>
      <?php foreach($data['cart'] as $id => $item): ?>
        <tr>
          <td><?= $item['name']; ?></td>
          <td><?= $item['qty']; ?></td>
          <td>€<?= number_format($item['price'], 2); ?></td>
          <td>€<?= number_format($item['price'] * $item['qty'], 2); ?></td>
          <td>
            <a href="<?= URLROOT . '/product/removeFromCart/' . $id ?>" class="btn btn-sm btn-danger">Remove</a>
          </td>
        </tr>
        <?php $grandTotal += $item['price'] * $item['qty']; ?>
      <?php endforeach; ?>
    </tbody>
  </table>
  <h4 class="text-end">Grand Total: €<?= number_format($grandTotal, 2); ?></h4>
<?php endif; ?>

<?php require APPROOT . '/app/views/templates/footer.php'; ?>
