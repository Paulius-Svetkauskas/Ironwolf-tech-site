<?php require APPROOT . '/app/views/templates/header.php'; ?>

<div class="container mt-5">
    <h1 class="mb-4">Our Products</h1>

    <?php if (!empty($data['products'])): ?>
        <div class="row">
            <?php foreach ($data['products'] as $product): ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <!-- Optional placeholder image -->
                        <img src="<?= URLROOT ?>/img/placeholder.jpg" class="card-img-top" alt="Product Image">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($product->name) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($product->description) ?></p>
                            <p class="card-text"><strong>€<?= htmlspecialchars($product->price) ?></strong></p>
                                <a href="<?= URLROOT ?>/product/addToCart/<?= $product->id ?>" class="btn btn-success mt-2">Add to Cart</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>No products found.</p>
    <?php endif; ?>
</div>

<?php require APPROOT . '/app/views/templates/footer.php'; ?>
