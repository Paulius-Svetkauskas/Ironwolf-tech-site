
<?php require APPROOT . '/app/views/templates/header.php'; ?>

<div class="container mt-5">
    <h2>My Account</h2>
    <p>Welcome, <?= htmlspecialchars($data['user']->username) ?>!</p>
    <p>Email: <?= htmlspecialchars($data['user']->email) ?></p>

    <form method="POST" action="<?= URLROOT ?>/user/delete" onsubmit="return confirm('Are you sure you want to delete your account?');">
        <button type="submit" class="btn btn-danger mt-3">Delete My Account</button>
    </form>
    

<?php require APPROOT . '/app/views/templates/footer.php'; ?>
