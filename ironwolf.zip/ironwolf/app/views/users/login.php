
<?php require APPROOT . '/app/views/templates/header.php'; ?>

<div class="container mt-5">
    <h2>Login</h2>
    <form action="<?php echo URLROOT; ?>/user/login" method="post">
        <div class="mb-3">
            <label>Username</label>
            <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Login</button>
    </form>
</div>

<?php require APPROOT . '/app/views/templates/footer.php'; ?>
