
<?php require APPROOT . '/app/views/templates/header.php'; ?>

<div class="container mt-5">
    <h2>Register</h2>
    <form action="<?php echo URLROOT; ?>/user/register" method="post">
        <div class="mb-3">
            <label>Username</label>
            <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Confirm Password</label>
            <input type="password" name="confirm_password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Register</button>
    </form>
</div>

<?php require APPROOT . '/app/views/templates/footer.php'; ?>
