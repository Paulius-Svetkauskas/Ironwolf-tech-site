</div> <!-- container -->
  <footer class="bg-black text-center text-light py-3 mt-5">
    <p>&copy; <?php echo date("Y"); ?> IronWolf. All rights reserved.</p>
  </footer>
</body>
</html>
