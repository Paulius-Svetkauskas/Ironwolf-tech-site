CREATE DATABASE IF NOT EXISTS ironwolf;
USE ironwolf;

-- Users table
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  stock INT DEFAULT 0
);

-- Insert sample products
INSERT INTO products (name, description, price, stock) VALUES
('PC Repair', 'Complete desktop diagnostics and hardware repair', 49.99, 20),
('Phone Screen Replacement', 'High-quality screen repair for major phone brands', 89.99, 15),
('3D Printing - PLA', 'Custom PLA prints per gram', 0.15, 1000),
('3D Printing - Resin', 'Detailed resin printing per ml', 0.25, 800);

-- Insert test user
INSERT INTO users (username, email, password) VALUES (
  'testuser',
  'test@example.com',
  '$2y$10$EbyE/Ca4Gb3EpQZoGV1Bmu4CE5prjZDoWmc4QGOMQcy4bU1Zm1bWq' -- hashed: Test@123
);